package com.sushmita.myapp;
import com.sushmita.myapp.DBHelper;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class InventoryAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Item> itemList;

    public InventoryAdapter(Context context, ArrayList<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return itemList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.grid_item, parent, false);
        }

        TextView nameTextView = convertView.findViewById(R.id.itemName);
        TextView quantityTextView = convertView.findViewById(R.id.itemQuantity);

        Item item = itemList.get(position);
        nameTextView.setText(item.getName());
        quantityTextView.setText(String.valueOf(item.getQuantity()));

        return convertView;
    }
}
