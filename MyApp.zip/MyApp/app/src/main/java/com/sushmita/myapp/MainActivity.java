package com.sushmita.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView usernameTextView;
    Button registerButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find views
        usernameTextView = findViewById(R.id.usernameTextView);
        registerButton = findViewById(R.id.register_button);
        logoutButton = findViewById(R.id.logout_button);

        // Get username from Intent (Assuming user logged in)
        String username = getIntent().getStringExtra("USERNAME");
        if (username != null && !username.isEmpty()) {
            usernameTextView.setText("Welcome, " + username);
            usernameTextView.setVisibility(View.VISIBLE);
        }

        // Register Button Click
        registerButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // Logout Button Click
        logoutButton.setOnClickListener(v -> {
            // Redirect to Login
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }
}
